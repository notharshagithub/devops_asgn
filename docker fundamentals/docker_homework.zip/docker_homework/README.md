# Docker Homework

## Task: Hello World Applications

### Node.js

```bash
$ cd nodejs-app
$ docker build -t nodejs-app .
$ docker run -d -p 3000:3000 --name nodejs-app nodejs-app
$ curl http://localhost:3000
<h1>Hello World from Node.js</h1>
```

Open: `http://localhost:3000`

### Python

```bash
$ cd python-app
$ docker build -t python-app .
$ docker run -d -p 5000:5000 --name python-app python-app
$ curl http://localhost:5000
<h1>Hello World from Python</h1>
```

Open: `http://localhost:5000`

### Java

```bash
$ cd java-app
$ docker build -t java-app .
$ docker run -d -p 8080:8080 --name java-app java-app
$ curl http://localhost:8080
<h1>Hello World from Java</h1>
```

Open: `http://localhost:8080`

### Apache

```bash
$ cd Apache-app
$ docker build -t apache-app .
$ docker run -d -p 8081:80 --name apache-app apache-app
$ curl http://localhost:8081
<h1>Hello World from Apache</h1>
```

Open: `http://localhost:8081`

### React

```bash
$ cd React-app
$ docker build -t react-app .
$ docker run -d -p 5173:5173 --name react-app react-app
$ curl http://localhost:5173
```

Open: `http://localhost:5173`

### Nginx

```bash
$ cd nginx-app
$ docker build -t nginx-app .
$ docker run -d -p 8082:80 --name nginx-app nginx-app
$ curl http://localhost:8082
<h1>Hello World from Nginx</h1>
```

Open: `http://localhost:8082`

## Check Running Containers

```bash
$ docker ps
```

## Stop Containers

```bash
$ docker stop nodejs-app python-app java-app apache-app react-app nginx-app
```

## Project Structure

```text
docker_homework/
├── nodejs-app/
├── python-app/
├── java-app/
├── Apache-app/
├── React-app/
├── nginx-app/
└── README.md
```
